library(testthat)
library(iNEXT)

test_check("iNEXT")
