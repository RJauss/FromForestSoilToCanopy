# v0.1.0 (Initial release)

* Implement combination matrix for x axis
* Provide convenience functions to create UpSet plots and handle
list columns
