library(testthat)
library(funrar)

test_check("funrar")
